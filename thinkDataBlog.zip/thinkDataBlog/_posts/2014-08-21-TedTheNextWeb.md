---
layout: blog_entry
title: TBL The Next Web
author: Brendan Stennett
---

20 years ago, Tim Berners-Lee invented the World Wide Web. For his next project, he's building a web for open, linked data that could do for numbers what the Web did for words, pictures, video: unlock our data and reframe the way we use it together.

Check out this [video](https://www.youtube.com/watch?v=gKiaLSJW5xI) of Tim Berners Lee giving a TED Talk about 'The Next Web'.
Check out this [video](https://www.youtube.com/watch?v=gKiaLSJW5xI) of Tim Berners Lee giving a TED Talk about 'The Next Web'.
Check out this [video](https://www.youtube.com/watch?v=gKiaLSJW5xI) of Tim Berners Lee giving a TED Talk about 'The Next Web'.
Check out this [video](https://www.youtube.com/watch?v=gKiaLSJW5xI) of Tim Berners Lee giving a TED Talk about 'The Next Web'.

<iframe width="560" height="315" src="//www.youtube.com/embed/OM6XIICm_qo" frameborder="0" allowfullscreen></iframe>