---
layout: blog_entry
title: Governments Are Going Digital
author: Bryan Smith
---

https://www.bcgperspectives.com/content/articles/public_sector_digital_economy_governments_going_digital_infographic/?utm_source=2014Aug&utm_medium=Email&utm_campaign=Ealert
